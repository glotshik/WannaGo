package com.example.listr

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.listr.databinding.FragmentNaughtyBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

private const val TAG = "NaughtyFragment"
class NaughtyFragment : Fragment() {
    private var _binding: FragmentNaughtyBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "binding cannot be created. Is view created?"
        }

    private val db = Firebase.firestore

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNaughtyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.addNaughtyBtn.setOnClickListener {
            addNaughtyPerson()
        }
    }

    private fun addNaughtyPerson() {
        val person = hashMapOf<String, String>(
            "name" to "${binding.naughtyPersonInput.text}"
        )

        // Add a new document to the "naughty" collection
        db.collection("naughty")
            .add(person)
            .addOnSuccessListener { documentReference ->
                Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                binding.naughtyPersonInput.text.clear() // Clear input after adding
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error adding document", e)
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}