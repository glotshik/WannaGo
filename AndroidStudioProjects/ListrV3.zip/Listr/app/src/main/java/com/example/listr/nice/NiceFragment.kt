package com.example.listr

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.listr.databinding.FragmentNiceBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

private const val TAG = "NiceFragment"
class NiceFragment : Fragment() {
    private var _binding: FragmentNiceBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "binding cannot be created. Is view created?"
        }

    private val db = Firebase.firestore

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNiceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.addNiceBtn.setOnClickListener {
            addNicePerson()
        }
    }

    private fun addNicePerson() {
        val person = hashMapOf<String, String>(
            "name" to "${binding.nicePersonInput.text}"
        )

        // Add a new document to the "nice" collection
        db.collection("nice")
            .add(person)
            .addOnSuccessListener { documentReference ->
                Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                binding.nicePersonInput.text.clear() // Clear input after adding
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error adding document", e)
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}