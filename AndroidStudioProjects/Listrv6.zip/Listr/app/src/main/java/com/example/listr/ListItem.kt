package com.example.listr

data class ListItem(val name: String, val id: String = "")