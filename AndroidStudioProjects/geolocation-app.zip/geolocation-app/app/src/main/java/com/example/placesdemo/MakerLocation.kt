package com.example.placesdemo

data class MarkerLocation(
    val latitude: Double,
    val longitude: Double,
    val address: String
)